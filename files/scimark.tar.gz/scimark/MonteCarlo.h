double MonteCarlo_integrate(int Num_samples);
double MonteCarlo_num_flops(int Num_samples);
