build_scimark() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        make CFLAGS=" -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15 "
    elif [ $ARCH = "aarch64" ]; then
        make
    else
        make CFLAGS="-msse4"
    fi
}

build_scimark
